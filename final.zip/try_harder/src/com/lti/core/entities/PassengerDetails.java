package com.lti.core.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="PassengerDetails")
@Table(name="PASSENGERDETAIL")
public class PassengerDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "P_ID_SEQ")
    @SequenceGenerator(sequenceName = "p_id_seq", allocationSize = 1, name = "P_ID_SEQ")
	@Column(name="P_ID")
	private int PID;
	@Column(name="PNAME")
	private String pname;
	@Column(name="GENDER")
	private String gender;
	@Column(name="AGE")
	private int age;
	public int getPID() {
		return PID;
	}
	public void setPID(int pID) {
		PID = pID;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "PassengerDetails [PID=" + PID + ", pname=" + pname + ", gender=" + gender + ", age=" + age + "]";
	}
	public PassengerDetails( String pname, String gender, int age) {
		super();
		
		this.pname = pname;
		this.gender = gender;
		this.age = age;
	}
	public PassengerDetails() {
		System.out.println("pAss created");
	}
	
	
	
	
}
