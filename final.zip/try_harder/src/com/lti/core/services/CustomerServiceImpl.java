package com.lti.core.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.core.daos.CustomerDao;
import com.lti.core.entities.Customer;

@Service
public class CustomerServiceImpl implements CustomerServices{

	@Autowired
	CustomerDao custDao;
	
	@Override
	@Transactional
	public boolean joinNewCustomer(Customer cust) {
		int result = getCustDao().addNewCustomer(cust);
		if(result==1)
		{
			return true;
		}
		else {
			return false;
		}
	}

	public CustomerDao getCustDao() {
		return custDao;
	}

	public void setCustDao(CustomerDao custDao) {
		this.custDao = custDao;
	}
	
}
