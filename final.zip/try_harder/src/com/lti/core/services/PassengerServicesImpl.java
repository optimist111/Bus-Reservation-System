package com.lti.core.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.core.daos.PassengerDao;
import com.lti.core.entities.Admin;
import com.lti.core.entities.PassengerDetails;

@Service
public class PassengerServicesImpl implements PassengerServices{

	@Autowired
	PassengerDao pdao;

	public PassengerDao getPdao() {
		return pdao;
	}

	public void setPdao(PassengerDao pdao) {
		this.pdao = pdao;
	}
	
	@Override
	@Transactional
	public void joinNewPassenger(PassengerDetails[] pd) {
		for(PassengerDetails p : pd) {
			pdao.addNewPassenger(p);
		}
	}

	@Override
	public List<PassengerDetails> findAllPassengers() {
		List<PassengerDetails> list = getPdao().readPassDetails();
		return list;
	}
}	
