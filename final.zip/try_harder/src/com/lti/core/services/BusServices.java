package com.lti.core.services;

import com.lti.core.entities.AddBus;

public interface BusServices {
	public AddBus getBusDetails(int busId);
}
