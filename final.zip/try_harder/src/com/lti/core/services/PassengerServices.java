package com.lti.core.services;


import java.util.List;

import com.lti.core.entities.PassengerDetails;

public interface PassengerServices {
	public void joinNewPassenger(PassengerDetails[] pd);
	public List<PassengerDetails> findAllPassengers();
}
