package com.lti.core.services;

import com.lti.core.entities.Customer;

//import com.lti.core.entities.Admin;

public interface CustomerServices {
	public boolean joinNewCustomer(Customer cust);
}
