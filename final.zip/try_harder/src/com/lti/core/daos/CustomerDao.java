package com.lti.core.daos;

import com.lti.core.entities.Customer;
//import com.lti.core.entities.PassengerDetails;

public interface CustomerDao {
	public int addNewCustomer(Customer cust);
}
