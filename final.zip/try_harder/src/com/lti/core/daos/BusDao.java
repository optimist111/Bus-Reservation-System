package com.lti.core.daos;

import com.lti.core.entities.AddBus;

public interface BusDao {
	public AddBus getBusDetails(int busId);
}
