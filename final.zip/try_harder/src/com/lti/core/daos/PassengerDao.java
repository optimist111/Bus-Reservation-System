package com.lti.core.daos;

import java.util.List;

import com.lti.core.entities.AddBus;
import com.lti.core.entities.PassengerDetails;

public interface PassengerDao {
	public int addNewPassenger(PassengerDetails pd);
	public List<PassengerDetails> readPassDetails();
}
