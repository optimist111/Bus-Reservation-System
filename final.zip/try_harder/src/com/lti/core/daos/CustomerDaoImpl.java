package com.lti.core.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.lti.core.entities.Customer;
import com.lti.core.entities.PassengerDetails;

@Repository("custDao")
public class CustomerDaoImpl implements CustomerDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addNewCustomer(Customer cust) {
		entityManager.persist(cust);
		return 1;
	}

}
