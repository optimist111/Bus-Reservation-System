package com.lti.core.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.lti.core.entities.AddBus;
import com.lti.core.entities.PassengerDetails;

@Repository("pDao")
public class PassengerDaoImpl implements PassengerDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addNewPassenger(PassengerDetails pd) {
		entityManager.persist(pd);
		return 1;
	}

	@Override
	public List<PassengerDetails> readPassDetails() {
		String jpql = "From PassengerDetails";
		TypedQuery<PassengerDetails> tquery = entityManager.createQuery(jpql, PassengerDetails.class);
		List<PassengerDetails> list = tquery.getResultList();
		return list;
	}

}
