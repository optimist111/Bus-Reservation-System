package com.lti.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.core.entities.Admin;
import com.lti.core.entities.Customer;
import com.lti.core.services.CustomerServices;

@Controller
public class CustomerController {
	
	@Autowired
	private CustomerServices cServices;
	
	//http://localhost:8082/try_harder/custSignup.do
	@RequestMapping(path="custSignup.do", method=RequestMethod.GET)
	public String adminSignupPage(){
		return "CustSignup";
	}
	
	@RequestMapping(path="custSignup.do", method=RequestMethod.POST)
	public String addNewAdmin(@RequestParam("fName") String fName, @RequestParam("lName") String lName,@RequestParam("phoneNum") long phoneNum,@RequestParam("email") String email,@RequestParam("password") String password){

		Customer cust = new Customer();

		cust.setfName(fName);
		cust.setlName(lName);
		cust.setPhoneNum(phoneNum);
		cust.setEmail(email);
		cust.setPassword(password);
		
		boolean result = cServices.joinNewCustomer(cust);
		if(result){
			return "redirect:customerDashboard.do";
		}
		return "Error";
	}
}
